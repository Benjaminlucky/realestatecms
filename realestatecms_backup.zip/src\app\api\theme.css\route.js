import { API_URL } from "@/config/site";

// Route Handlers don't use `export const revalidate`.
// We control freshness via Cache-Control headers on the Response
// and cache: 'no-store' on the internal fetch so we always read
// the latest settings from the DB — theme changes go live immediately.

const DEFAULTS = {
  theme_primary: "#ff6b6b",
  theme_primary_dark: "#0f172a",
  theme_primary_light: "#38bdf8",
  theme_primary_muted: "#d1fae5",
  theme_secondary: "#1c1c2e",
  theme_secondary_dark: "#0f0f1a",
  theme_secondary_mid: "#2d2d44",
  theme_secondary_light: "#3d3d5c",
  theme_accent: "#f59e0b",
  theme_accent_light: "#fcd34d",
  theme_surface: "#ffffff",
  theme_surface_2: "#f8fafc",
  theme_surface_3: "#f1f5f9",
  theme_border: "#e2e8f0",
  theme_text: "#0f172a",
  theme_text_secondary: "#475569",
  theme_text_muted: "#94a3b8",
  theme_radius: "0.625rem",
  theme_radius_lg: "1rem",
  theme_radius_xl: "1.5rem",
};

export async function GET() {
  let settings = {};

  try {
    // cache: 'no-store' bypasses Next.js data cache entirely —
    // every request to /api/theme.css fetches fresh settings from the DB.
    // The browser-level Cache-Control (30s) prevents hammering the endpoint.
    const base = process.env.API_URL || API_URL;
    const res = await fetch(`${base}/settings`, {
      cache: "no-store",
      headers: { "Content-Type": "application/json" },
    });
    if (res.ok) {
      const json = await res.json();
      settings = json?.data?.settings || {};
    }
  } catch {
    // Serve defaults silently if API is unreachable
  }

  // Merge DB values over defaults — skip empty strings
  const t = { ...DEFAULTS };
  for (const [k, v] of Object.entries(settings)) {
    if (k in DEFAULTS && v && String(v).trim()) {
      t[k] = String(v).trim();
    }
  }

  // Use :root with !important on each property so the theme CSS
  // wins over Tailwind v4's @theme block and the shadcn @layer base
  // (:root) block regardless of load order.
  const vars = [
    ["--color-primary", t.theme_primary],
    ["--color-primary-dark", t.theme_primary_dark],
    ["--color-primary-light", t.theme_primary_light],
    ["--color-primary-muted", t.theme_primary_muted],
    ["--color-secondary", t.theme_secondary],
    ["--color-secondary-dark", t.theme_secondary_dark],
    ["--color-secondary-mid", t.theme_secondary_mid],
    ["--color-secondary-light", t.theme_secondary_light],
    ["--color-accent", t.theme_accent],
    ["--color-accent-light", t.theme_accent_light],
    ["--color-surface", t.theme_surface],
    ["--color-surface-2", t.theme_surface_2],
    ["--color-surface-3", t.theme_surface_3],
    ["--color-border", t.theme_border],
    ["--color-text", t.theme_text],
    ["--color-text-secondary", t.theme_text_secondary],
    ["--color-text-muted", t.theme_text_muted],
    ["--radius", t.theme_radius],
    ["--radius-lg", t.theme_radius_lg],
    ["--radius-xl", t.theme_radius_xl],
    ["--shadow-coral", `0 4px 16px ${t.theme_primary}55`],
  ];

  const declarations = vars
    .map(([prop, val]) => `  ${prop}: ${val} !important;`)
    .join("\n");

  const css = `
/* Dynamic theme — /api/theme.css — reads live from DB */
:root {
${declarations}
}

/* Also set on html and body to beat Tailwind @theme specificity */
html, body {
${declarations}
}
`.trim();

  return new Response(css, {
    headers: {
      "Content-Type": "text/css; charset=utf-8",
      // Short browser cache: revalidate after 30s, serve stale for up to 60s
      // This means changes propagate within ~30s without the browser hammering /api/theme.css
      "Cache-Control": "public, max-age=30, stale-while-revalidate=60",
    },
  });
}
