import { Plus_Jakarta_Sans, Inter } from "next/font/google";
import { Toaster } from "@/components/ui/sonner";
import "./globals.css";

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-heading",
  weight: ["400", "500", "600", "700", "800"],
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-body",
  weight: ["400", "500", "600"],
  display: "swap",
});

export const metadata = {
  title: "Real Estate CMS",
  description: "Premium Properties Across Nigeria",
};

export default function RootLayout({ children }) {
  return (
    <html
      lang="en-NG"
      className={`${plusJakarta.variable} ${inter.variable}`}
      suppressHydrationWarning
    >
      <head>
        {/*
          Dynamic theme stylesheet.
          - Served by the /api/theme.css Route Handler
          - Reads settings from DB on every request (cache: no-store)
          - Browser caches for 30s then revalidates
          - Loads AFTER globals.css so its :root !important declarations win
        */}
        <link rel="stylesheet" href="/api/theme.css" />
      </head>
      <body className="antialiased">
        {children}
        <Toaster
          richColors
          position="top-right"
          toastOptions={{ style: { fontFamily: "var(--font-body)" } }}
        />
      </body>
    </html>
  );
}
