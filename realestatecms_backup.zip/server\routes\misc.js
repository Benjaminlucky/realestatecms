"use strict";

const router = require("express").Router();
const bcrypt = require("bcryptjs");
const mongoose = require("mongoose");
const {
  ok,
  created,
  fail,
  paginated,
  parsePagination,
} = require("../lib/helpers");
const { requireAuth, requireSuperAdmin } = require("../middleware/auth");
const { upload } = require("../middleware/upload");
const { Enquiry, Setting, Media } = require("../models/Misc");
const Admin = require("../models/Admin");
const Land = require("../models/Land");
const House = require("../models/House");
const { BlogPost } = require("../models/Blog");
const { sendEnquiryNotification } = require("../services/email");
const { revalidate } = require("../lib/revalidate");

// ══════════════════════════════════════════════════════════════════
// ENQUIRIES
// ══════════════════════════════════════════════════════════════════

// POST /enquiries — public submission
router.post("/enquiries", async (req, res, next) => {
  try {
    const {
      first_name,
      last_name,
      email,
      phone,
      inquiry_type,
      property_type,
      budget,
      preferred_location,
      message,
      listing_type,
      listing_id,
      source,
    } = req.body;

    // ── Validation ────────────────────────────────────────────────
    if (!first_name?.trim()) {
      return fail(res, "First name is required");
    }
    if (!phone?.trim()) {
      return fail(res, "Phone number is required");
    }
    // message is optional from the hero form (additional_info maps here)
    // but we store something meaningful either way
    const resolvedMessage =
      message?.trim() ||
      [
        inquiry_type && `Inquiry type: ${inquiry_type}`,
        property_type && `Property type: ${property_type}`,
        budget && `Budget: ${budget}`,
        preferred_location && `Location: ${preferred_location}`,
      ]
        .filter(Boolean)
        .join("\n") ||
      "No additional details provided.";

    // ── Save to DB ────────────────────────────────────────────────
    const doc = await Enquiry.create({
      first_name: first_name.trim(),
      last_name: last_name?.trim() || "",
      email: email?.toLowerCase().trim() || "",
      phone: phone.trim(),
      inquiry_type: inquiry_type?.trim() || "",
      // Store hero-form extras as part of the enquiry
      property_type: property_type?.trim() || "",
      budget: budget?.trim() || "",
      preferred_location: preferred_location?.trim() || "",
      message: resolvedMessage,
      listing_type: listing_type || "general",
      listing_id:
        listing_id && mongoose.isValidObjectId(listing_id)
          ? listing_id
          : undefined,
      source: source || "website",
      status: "new",
    });

    // ── Email notification — fire-and-forget ──────────────────────
    // Fetch the notification_email and email_from settings from DB.
    // We do this asynchronously so it never delays the HTTP response.
    setImmediate(async () => {
      try {
        const settingDocs = await Setting.find({
          key: { $in: ["notification_email", "email_from", "site_name"] },
        }).lean();
        const settings = settingDocs.reduce((acc, s) => {
          acc[s.key] = s.value;
          return acc;
        }, {});

        await sendEnquiryNotification(
          {
            ...doc.toObject(),
            // pass hero-form specific fields that may not be in schema
            property_type: doc.property_type || property_type,
            budget: doc.budget || budget,
            preferred_location: doc.preferred_location || preferred_location,
          },
          settings,
        );
      } catch (e) {
        console.error("[Enquiry] Post-save email error:", e.message);
      }
    });

    return created(res, doc, "Enquiry submitted successfully");
  } catch (err) {
    next(err);
  }
});

// GET /admin/enquiries
// FIX B1 + B3: use parsePagination(req.query) and correct paginated() signature
router.get("/admin/enquiries", requireAuth, async (req, res, next) => {
  try {
    const { page, perPage, skip } = parsePagination(req.query); // ← B1 fix
    const { status, q } = req.query;

    const filter = {};
    if (status) filter.status = status;
    if (q) {
      const re = new RegExp(q.trim(), "i");
      filter.$or = [
        { first_name: re },
        { last_name: re },
        { email: re },
        { phone: re },
        { message: re },
      ];
    }

    const [data, total, newCount] = await Promise.all([
      Enquiry.find(filter)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(perPage) // ← B1 fix: was `limit` (undefined), now perPage
        .lean(),
      Enquiry.countDocuments(filter),
      Enquiry.countDocuments({ status: "new" }),
    ]);

    // B3 fix: correct paginated() signature + surface newCount in response
    return res.json({
      success: true,
      message: "Success",
      data,
      total,
      page,
      perPage,
      totalPages: Math.ceil(total / perPage),
      newCount, // ← extra field consumed by dashboard badge
    });
  } catch (err) {
    next(err);
  }
});

// GET /admin/enquiries/:id
router.get("/admin/enquiries/:id", requireAuth, async (req, res, next) => {
  try {
    const doc = await Enquiry.findById(req.params.id).lean();
    if (!doc) return fail(res, "Enquiry not found", 404);
    return ok(res, doc);
  } catch (err) {
    next(err);
  }
});

// PUT /admin/enquiries/:id — update status / notes
router.put("/admin/enquiries/:id", requireAuth, async (req, res, next) => {
  try {
    const { status, notes } = req.body;
    const doc = await Enquiry.findByIdAndUpdate(
      req.params.id,
      { ...(status && { status }), ...(notes !== undefined && { notes }) },
      { new: true },
    ).lean();
    if (!doc) return fail(res, "Enquiry not found", 404);
    return ok(res, doc, "Enquiry updated");
  } catch (err) {
    next(err);
  }
});

// DELETE /admin/enquiries/:id
router.delete("/admin/enquiries/:id", requireAuth, async (req, res, next) => {
  try {
    const doc = await Enquiry.findByIdAndDelete(req.params.id);
    if (!doc) return fail(res, "Enquiry not found", 404);
    return ok(res, null, "Enquiry deleted");
  } catch (err) {
    next(err);
  }
});

// ══════════════════════════════════════════════════════════════════
// ABOUT PAGE
// ══════════════════════════════════════════════════════════════════

// GET /about — public, ISR-cached by Next.js
router.get("/about", async (req, res, next) => {
  try {
    const doc = await Setting.findOne({ key: "about_page" }).lean();
    const data = doc?.value ? JSON.parse(doc.value) : {};
    return ok(res, data);
  } catch (err) {
    next(err);
  }
});

// PUT /admin/about — protected, saves the full about page JSON blob
router.put("/admin/about", requireAuth, async (req, res, next) => {
  try {
    const value = JSON.stringify(req.body);
    await Setting.findOneAndUpdate(
      { key: "about_page" },
      { key: "about_page", value, group_name: "about" },
      { upsert: true, new: true },
    );
    revalidate(["/about"]);
    return ok(res, null, "About page saved");
  } catch (err) {
    next(err);
  }
});

// ══════════════════════════════════════════════════════════════════
// SETTINGS
// ══════════════════════════════════════════════════════════════════

// GET /settings — public
router.get("/settings", async (req, res, next) => {
  try {
    const docs = await Setting.find({ group_name: "general" }).lean();
    const settings = docs.reduce((acc, s) => {
      acc[s.key] = s.value;
      return acc;
    }, {});
    return ok(res, { settings });
  } catch (err) {
    next(err);
  }
});

// GET /admin/settings
router.get("/admin/settings", requireAuth, async (req, res, next) => {
  try {
    const docs = await Setting.find({}).sort({ group_name: 1, key: 1 }).lean();
    const settings = docs.reduce((acc, s) => {
      acc[s.key] = s.value;
      return acc;
    }, {});
    return ok(res, { settings, rows: docs });
  } catch (err) {
    next(err);
  }
});

// PUT /admin/settings
router.put("/admin/settings", requireAuth, async (req, res, next) => {
  try {
    const updates = req.body; // { key: value, ... }
    const ops = Object.entries(updates).map(([key, value]) =>
      Setting.findOneAndUpdate(
        { key },
        { key, value: value ?? "", group_name: "general" },
        { upsert: true, new: true },
      ),
    );
    await Promise.all(ops);
    return ok(res, null, "Settings saved");
  } catch (err) {
    next(err);
  }
});

// ══════════════════════════════════════════════════════════════════
// MEDIA
// ══════════════════════════════════════════════════════════════════

// GET /admin/media
// FIX B1: use parsePagination(req.query)
router.get("/admin/media", requireAuth, async (req, res, next) => {
  try {
    const { page, perPage, skip } = parsePagination(req.query); // ← B1 fix
    const { folder } = req.query;
    const filter = folder ? { folder } : {};
    const [data, total] = await Promise.all([
      Media.find(filter)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(perPage)
        .lean(),
      Media.countDocuments(filter),
    ]);
    return paginated(res, { data, total, page, perPage }); // ← B3 fix
  } catch (err) {
    next(err);
  }
});

// POST /admin/media — upload via Cloudinary (multer-storage-cloudinary)
router.post(
  "/admin/media",
  requireAuth,
  upload.single("file"),
  async (req, res, next) => {
    try {
      if (!req.file) return fail(res, "No file uploaded");

      const folder = req.body.folder || "general";
      const doc = await Media.create({
        filename: req.file.filename || req.file.originalname,
        original_name: req.file.originalname,
        file_path: req.file.path, // Cloudinary HTTPS URL
        public_id: req.file.filename, // Cloudinary public_id
        file_size: req.file.size,
        mime_type: req.file.mimetype,
        folder,
        uploaded_by: req.admin?._id,
      });

      return created(res, doc, "File uploaded");
    } catch (err) {
      next(err);
    }
  },
);

// PUT /admin/media/:id
router.put("/admin/media/:id", requireAuth, async (req, res, next) => {
  try {
    const { alt_text } = req.body;
    const doc = await Media.findByIdAndUpdate(
      req.params.id,
      { alt_text },
      { new: true },
    ).lean();
    if (!doc) return fail(res, "Media not found", 404);
    return ok(res, doc, "Updated");
  } catch (err) {
    next(err);
  }
});

// DELETE /admin/media/:id
router.delete("/admin/media/:id", requireAuth, async (req, res, next) => {
  try {
    const doc = await Media.findById(req.params.id);
    if (!doc) return fail(res, "Media not found", 404);

    if (doc.public_id) {
      try {
        const cloudinary = require("../config/cloudinary");
        await cloudinary.uploader.destroy(doc.public_id);
      } catch (e) {
        console.warn("[Media] Cloudinary delete failed:", e.message);
      }
    }

    await doc.deleteOne();
    return ok(res, null, "File deleted");
  } catch (err) {
    next(err);
  }
});

// ══════════════════════════════════════════════════════════════════
// DASHBOARD STATS
// ══════════════════════════════════════════════════════════════════

router.get("/admin/stats", requireAuth, async (req, res, next) => {
  try {
    const [
      landsCount,
      housesCount,
      blogCount,
      enquiriesCount,
      newEnquiries,
      recentEnquiries,
      topLands,
    ] = await Promise.all([
      Land.countDocuments({}),
      House.countDocuments({}),
      BlogPost.countDocuments({ status: "published" }),
      Enquiry.countDocuments({}),
      Enquiry.countDocuments({ status: "new" }),
      Enquiry.find({})
        .sort({ createdAt: -1 })
        .limit(5)
        .select("first_name last_name phone inquiry_type status createdAt")
        .lean(),
      Land.find({})
        .sort({ views_count: -1 })
        .limit(5)
        .select("estate_name slug views_count")
        .lean(),
    ]);

    // Monthly enquiries — last 6 months
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const monthlyRaw = await Enquiry.aggregate([
      { $match: { createdAt: { $gte: sixMonthsAgo } } },
      {
        $group: {
          _id: { $dateToString: { format: "%Y-%m", date: "$createdAt" } },
          count: { $sum: 1 },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    const monthNames = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ];
    const monthly_enquiries = monthlyRaw.map((m) => ({
      month: monthNames[parseInt(m._id.split("-")[1]) - 1],
      count: m.count,
    }));

    return ok(res, {
      counts: {
        lands: landsCount,
        houses: housesCount,
        blog_posts: blogCount,
        enquiries: enquiriesCount,
        new_enquiries: newEnquiries,
      },
      monthly_enquiries,
      recent_enquiries: recentEnquiries,
      top_lands: topLands,
    });
  } catch (err) {
    next(err);
  }
});

// ══════════════════════════════════════════════════════════════════
// PUBLIC STATS  — GET /stats/public
// No auth required. Used by the public homepage hero section.
// ISR-cached for 5 min via Next.js serverFetch on the frontend.
// ══════════════════════════════════════════════════════════════════

router.get("/stats/public", async (req, res, next) => {
  try {
    const [landsCount, housesCount, enquiriesCount, landStates, houseStates] =
      await Promise.all([
        Land.countDocuments({ status: { $ne: "coming_soon" } }),
        House.countDocuments({ status: { $ne: "coming_soon" } }),
        Enquiry.countDocuments({}),
        Land.distinct("state", { state: { $nin: ["", null] } }),
        House.distinct("state", { state: { $nin: ["", null] } }),
      ]);

    // Deduplicated union of states covered across both property types
    const stateSet = new Set([
      ...landStates.filter(Boolean),
      ...houseStates.filter(Boolean),
    ]);

    return ok(res, {
      total_listings: landsCount + housesCount,
      total_lands: landsCount,
      total_houses: housesCount,
      total_enquiries: enquiriesCount,
      states_covered: stateSet.size,
    });
  } catch (err) {
    next(err);
  }
});

// ══════════════════════════════════════════════════════════════════
// SEARCH
// ══════════════════════════════════════════════════════════════════

router.get("/search", async (req, res, next) => {
  try {
    const { q } = req.query;
    if (!q || q.trim().length < 2) return ok(res, { lands: [], houses: [] });

    const re = new RegExp(q.trim(), "i");

    const [lands, houses] = await Promise.all([
      Land.find({
        status: "available",
        $or: [{ estate_name: re }, { location: re }, { state: re }],
      })
        .select("estate_name slug location state price feature_image")
        .limit(5)
        .lean(),
      House.find({
        status: "available",
        $or: [{ title: re }, { location: re }, { state: re }],
      })
        .select("title slug location state price feature_image bedrooms")
        .limit(5)
        .lean(),
    ]);

    return ok(res, { lands, houses });
  } catch (err) {
    next(err);
  }
});

// ══════════════════════════════════════════════════════════════════
// TEAM
// ══════════════════════════════════════════════════════════════════

// GET /admin/team
router.get("/admin/team", requireAuth, async (req, res, next) => {
  try {
    const members = await Admin.find({}).sort({ createdAt: 1 }).lean();
    return ok(res, members);
  } catch (err) {
    next(err);
  }
});

// GET /admin/team/:id
router.get("/admin/team/:id", requireAuth, async (req, res, next) => {
  try {
    const member = await Admin.findById(req.params.id).lean();
    if (!member) return fail(res, "Team member not found", 404);
    return ok(res, member);
  } catch (err) {
    next(err);
  }
});

// POST /admin/team — super admin only
router.post(
  "/admin/team",
  requireAuth,
  requireSuperAdmin,
  async (req, res, next) => {
    try {
      const {
        first_name,
        last_name,
        email,
        password,
        role = "admin",
      } = req.body;
      if (!first_name || !email || !password) {
        return fail(res, "Name, email, and password are required");
      }
      const existing = await Admin.findOne({ email: email.toLowerCase() });
      if (existing) return fail(res, "Email already in use", 409);

      const member = await Admin.create({
        first_name,
        last_name,
        email,
        password,
        role,
      });
      return created(res, member.toSafeObject(), "Team member created");
    } catch (err) {
      if (err.code === 11000) return fail(res, "Email already in use", 409);
      next(err);
    }
  },
);

// PUT /admin/team/:id
router.put("/admin/team/:id", requireAuth, async (req, res, next) => {
  try {
    const { first_name, last_name, email, role, phone, bio } = req.body;
    const member = await Admin.findByIdAndUpdate(
      req.params.id,
      { first_name, last_name, email, role, phone, bio },
      { new: true, runValidators: true },
    ).lean();
    if (!member) return fail(res, "Team member not found", 404);
    return ok(res, member, "Updated");
  } catch (err) {
    next(err);
  }
});

// PUT /admin/team/:id/password
router.put("/admin/team/:id/password", requireAuth, async (req, res, next) => {
  try {
    const { current_password, new_password } = req.body;
    const member = await Admin.findById(req.params.id);
    if (!member) return fail(res, "Not found", 404);

    const isSelf = String(req.admin._id) === String(member._id);
    const isSuper = req.admin.role === "super_admin";
    if (!isSelf && !isSuper) return fail(res, "Forbidden", 403);

    if (isSelf && !isSuper) {
      const valid = await member.comparePassword(current_password);
      if (!valid) return fail(res, "Current password is incorrect", 401);
    }

    member.password = new_password;
    await member.save();
    return ok(res, null, "Password updated");
  } catch (err) {
    next(err);
  }
});

// DELETE /admin/team/:id — super admin only
router.delete(
  "/admin/team/:id",
  requireAuth,
  requireSuperAdmin,
  async (req, res, next) => {
    try {
      if (String(req.admin._id) === String(req.params.id)) {
        return fail(res, "You cannot delete your own account");
      }
      const member = await Admin.findByIdAndDelete(req.params.id);
      if (!member) return fail(res, "Team member not found", 404);
      return ok(res, null, "Team member removed");
    } catch (err) {
      next(err);
    }
  },
);

module.exports = router;
