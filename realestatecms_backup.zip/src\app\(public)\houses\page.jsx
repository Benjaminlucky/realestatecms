import { notFound } from "next/navigation";
import { housesApi, settingsApi, serverFetch } from "@/lib/api";
import { SITE_CONFIG, SITE_URL } from "@/config/site";
import HouseDetailClient from "./HouseDetailClient";

export const revalidate = 300;

export async function generateMetadata({ params }) {
  const { slug } = await params;
  try {
    const [res, settingsRes] = await Promise.all([
      housesApi.getBySlug(slug),
      settingsApi.getPublic(),
    ]);
    const house = res?.data;
    const s = settingsRes?.settings || {};
    const siteName = s.site_name || SITE_CONFIG.name;
    if (!house) return { title: `Property Not Found — ${siteName}` };

    const title = house.meta_title || `${house.title} — ${siteName}`;
    const bedsText =
      house.bedrooms != null
        ? house.bedrooms === 0
          ? "Self Contain"
          : `${house.bedrooms}-Bedroom`
        : "";
    const description =
      house.meta_description ||
      `${bedsText} ${house.category || ""} for sale in ${house.location || house.state || "Nigeria"}. ${house.price ? `Price: ₦${Number(house.price).toLocaleString("en-NG")}.` : ""}`.trim();

    return {
      title,
      description,
      openGraph: {
        title,
        description,
        images: house.feature_image ? [house.feature_image] : [],
        url: `${SITE_URL}/houses/${slug}`,
        type: "website",
      },
      twitter: {
        card: "summary_large_image",
        title,
        description,
        images: house.feature_image ? [house.feature_image] : [],
      },
    };
  } catch {
    return { title: `House Listing — ${SITE_CONFIG.name}` };
  }
}

export default async function HouseDetailPage({ params }) {
  const { slug } = await params;

  let house = null;
  let settings = {};
  let related = [];

  try {
    const [houseRes, settingsRes] = await Promise.all([
      housesApi.getBySlug(slug),
      settingsApi.getPublic(),
    ]);
    house = houseRes?.data || null;
    settings = settingsRes?.settings || {};
  } catch {
    notFound();
  }

  if (!house) notFound();

  // ── Fetch related listings server-side via serverFetch ──────────
  // Strategy 1: same state + same category (most relevant).
  // Strategy 2: fallback to same state only if < 3 results.
  // Strategy 3: fallback to any available if still < 3.
  try {
    // Attempt 1 — same state + same category
    const qs1 = new URLSearchParams({
      state: house.state || "",
      category: house.category || "",
      perPage: "4",
    }).toString();

    const res1 = await serverFetch(`/houses?${qs1}`, {
      next: { revalidate: 300 },
    });
    let candidates = (res1?.data || []).filter((h) => h.slug !== slug);

    // Attempt 2 — same state, any category
    if (candidates.length < 3 && house.state) {
      const qs2 = new URLSearchParams({
        state: house.state,
        perPage: "5",
      }).toString();
      const res2 = await serverFetch(`/houses?${qs2}`, {
        next: { revalidate: 300 },
      });
      const extra = (res2?.data || []).filter(
        (h) => h.slug !== slug && !candidates.find((c) => c.slug === h.slug),
      );
      candidates = [...candidates, ...extra];
    }

    // Attempt 3 — any available house
    if (candidates.length < 3) {
      const res3 = await serverFetch(`/houses?perPage=5`, {
        next: { revalidate: 300 },
      });
      const extra = (res3?.data || []).filter(
        (h) => h.slug !== slug && !candidates.find((c) => c.slug === h.slug),
      );
      candidates = [...candidates, ...extra];
    }

    related = candidates.slice(0, 3);
  } catch {
    related = [];
  }

  return (
    <HouseDetailClient house={house} settings={settings} related={related} />
  );
}
