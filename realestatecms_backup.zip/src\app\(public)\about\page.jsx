import { serverFetch } from "@/lib/api";
import { SITE_CONFIG } from "@/config/site";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import AboutClient from "./AboutClient";

export const revalidate = 300;

export async function generateMetadata() {
  try {
    const [settingsRes, aboutRes] = await Promise.all([
      serverFetch("/settings", { next: { revalidate: 300 } }),
      serverFetch("/about", { next: { revalidate: 300 } }),
    ]);
    const s = settingsRes?.data?.settings || {};
    const a = aboutRes?.data || {};
    const name = s.site_name || SITE_CONFIG.name;
    return {
      title: `About Us — ${name}`,
      description:
        a.tagline ||
        `Learn more about ${name} — Nigeria's trusted real estate platform.`,
    };
  } catch {
    return { title: `About Us — ${SITE_CONFIG.name}` };
  }
}

export default async function AboutPage() {
  const [settingsRes, aboutRes] = await Promise.allSettled([
    serverFetch("/settings", { next: { revalidate: 300 } }),
    serverFetch("/about", { next: { revalidate: 300 } }),
  ]);

  const settings =
    settingsRes.status === "fulfilled"
      ? settingsRes.value?.data?.settings || {}
      : {};

  const about =
    aboutRes.status === "fulfilled" ? aboutRes.value?.data || {} : {};

  return (
    <>
      <Navbar settings={settings} />
      <main>
        <AboutClient about={about} settings={settings} />
      </main>
    </>
  );
}
